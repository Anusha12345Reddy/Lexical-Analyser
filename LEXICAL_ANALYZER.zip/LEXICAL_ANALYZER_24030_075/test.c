#include <stdio.h>
#include <string.h>
int main()
{
    int a = 10;
    float b = 5.6;
    return 0;    
}